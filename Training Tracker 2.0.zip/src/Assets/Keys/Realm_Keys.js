const publicKey = 'gyxxezev'
const privateKey = '07a5fade-0edd-4ce3-a824-a879f14fdfff'

export{
    publicKey,
    privateKey
}