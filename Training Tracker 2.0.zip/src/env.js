export const BASEURL = "https://trainingtrackerapi.mcareauto.com";
